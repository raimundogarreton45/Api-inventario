"""
Paquete principal de la aplicación.
"""

__version__ = "1.0.0"
