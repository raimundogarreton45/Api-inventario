"""
Paquete de rutas (endpoints de la API).
"""

from app.routes import auth, products, sales

__all__ = ["auth", "products", "sales"]
